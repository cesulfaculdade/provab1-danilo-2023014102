import { StyleSheet} from 'react-native';


const styles = StyleSheet.create({
    container: {
      backgroundColor: '#7A4A9E',
      alignItems: "center",
    },
  
    tittle: {
      width: 345,
      color: "#F2F2F2",
      fontSize: 24,
      marginTop: 62
    },

    subtittle: {
      height: 400,
      fontSize: 16,
      marginLeft: 350,
      width: 700,
      color: "#F2F2F2",
    },
    
    textt: {
      width: 345,
      height: 579,
      fontSize: 16,
      textAlign: "center",
      color: "#F2F2F2",
    },

    tarefas: {
      width: 345,
      fontWeight: 'bold',

      
    }
  });

export default styles