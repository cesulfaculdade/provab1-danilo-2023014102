import React from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Text, View } from 'react-native';
import styles from './styles'


export default function Home() {
    return (
      <View style={styles.container}>
        <Text style={styles.tittle}>
          Lista de Tarefas
        </Text>
          <Text style={styles.subtittle}>
            Adicione suas atividades a lista de tarefas
          </Text>
            <Text style={styles.textt}>
              Realizou todas as tarefas? Adicione tarefas a sua lista de pendências.
            </Text>
              <Text style={styles.tarefas}>
                Tarefas Pendentes
              </Text>
        <StatusBar style="auto" />
      </View>
    );
}



